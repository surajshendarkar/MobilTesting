package com.Test;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.SessionId;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class Demosession3 {

	public static void sessionCreation() throws MalformedURLException {
		
		
		// step1
		
		UiAutomator2Options option =new UiAutomator2Options();
		
		//step 2 add the capabilities 
		  option.setCapability("platformName", "Android"); 
		  option.setCapability("automationName","UiAutomator2"); 
		  option.setCapability("udid", "emulator-5554 ");
		  
		  
		  //step3
		  
		  URL url=new URL("http://127.0.0.1:4723");
		  
		  //Step4
		 
		  AndroidDriver driver =new AndroidDriver(url,option);
		  
		 String  SessionID = driver.getSessionId().toString();
		 
		 System.out.println("sesion created succesfully and sesionId is:"+SessionID);
		  
		  
	}
	
	public static void main(String[] args) throws MalformedURLException {
		
		sessionCreation();
		
	}
	
}
