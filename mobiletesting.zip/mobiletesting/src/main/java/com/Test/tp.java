package com.Test;

public class tp {

	
	/*
	
	// step1
	
			UiAutomator2Options option =new UiAutomator2Options();
			
			//step 2 add the capabilities 
			  option.setCapability("platformName", "Android"); 
			  option.setCapability("automationName","UiAutomator2"); 
			  option.setCapability("udid", "emulator-5554");
			//If the app is installed 
			  option.setCapability("apaPackage", "com.google.android.deskclock");
			  option.setCapability("appActivity", "com.android.deskclock.DeskClock");
			  
			//  option.setCapability("apaPackage", "com.google.android.googlequicksearchbox");
			 // option.setCapability("appActivity", "com.google.android.googlequicksearchbox.OneSearchActivity");
			  
			  
			  
			  
			//If we have .apk with us 
			  //String path 
		//	=System.getProperty("user.dir")+"\\src\\main\\resources\\WikipediaSample.apk"; 
			  //option.setCapability("app",path); 
			  //option.setCapability("noReset",true); 
			  //option.setCapability("autoGrantPermissions", true);
			  
			  //step3
			  
			  URL url=new URL("http://127.0.0.1:4723");
			  
			  //Step4
			 
			  AndroidDriver driver =new AndroidDriver(url,option);
			  
			  //step5
			 String  SessionID = driver.getSessionId().toString();
			 
			 System.out.println("sesion created succesfully and sesionId is:"+SessionID);
			 
			 //step6
			//Step-6 sample action 
			  WebElement stopwatch = driver.findElement(
					    AppiumBy.xpath("//android.widget.TextView[@resource-id='com.google.android.deskclock:id/navigation_bar_item_small_label_view' and @text='Stopwatch']")
					);
	 
	   
			  Thread.sleep(3000); 
			  stopwatch.click(); 
			   
			  System.out.println("Clicked on Stopwatch"); 
		*/ 
			 
}
