package DemoPriousclassNotUse;

public class Demosession {

	
    public static  void demo() {
    	
    	System.out.println("demo is printing ");
    }
    
    
    public static void main(String[] args) {
    	demo();
	}
}
