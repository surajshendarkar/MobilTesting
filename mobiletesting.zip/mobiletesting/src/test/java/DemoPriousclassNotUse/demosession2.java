package DemoPriousclassNotUse;


import java.net.MalformedURLException; 
import java.net.URL; 
 
 
import org.openqa.selenium.WebElement; 
 
import io.appium.java_client.AppiumBy; 
import io.appium.java_client.android.AndroidDriver; 
import io.appium.java_client.android.options.UiAutomator2Options;

public class demosession2 {
/*
 * Note- ek code ha basic vala aplya selenium chya workspace made gela ahe tithe pan ahe 
	public static void sessionCreation() throws MalformedURLException, 
	InterruptedException { 
	   
	  //step 1 
	  UiAutomator2Options option =new UiAutomator2Options(); 
	   
	  //step 2 add the capabilities 
	  option.setCapability("platformName", "Android"); 
	  option.setCapability("automationName","UiAutomator2"); 
	  //option.setCapability("udid", "emulator-5554"); 
	  option.setCapability("deviceName", "pixel_7"); 
	   
	  //If the app is installed 
	  option.setCapability("appPackage", "com.google.android.deskclock"); 
	  option.setCapability("appActivity", "com.android.deskclock.DeskClock");
	   
	  //If we have .apk with us 
	  //String path 
	=System.getProperty("user.dir")+"\\src\\main\\resources\\WikipediaSample.apk"; 
	  //option.setCapability("app",path); 
	  //option.setCapability("noReset",true); 
	  //option.setCapability("autoGrantPermissions", true); 
	   
	   
	  //Step-3 
	  URL url =new URL("http://127.0.0.1:4723"); 
	   
	  //Step-4 
	  AndroidDriver driver =new AndroidDriver(url, option); 
	   
	   
	   
	  //step-5 
	  String sessionID=driver.getSessionId().toString(); 
	  System.out.println("Session created successfull and session id is :"+sessionID); 
	   
	  //Step-6 sample action 
	  WebElement 
	stopwatch=driver.findElement(AppiumBy.id("com.google.android.deskclock:id/tab_menu_stopwatch")); 
	   
	  Thread.sleep(3000); 
	  stopwatch.click(); 
	   
	  System.out.println("Clicked on Stopwatch"); 
	   
	   
	    */
	 } 
	
	

