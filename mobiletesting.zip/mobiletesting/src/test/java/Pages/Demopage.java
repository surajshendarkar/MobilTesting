package Pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import dev.failsafe.internal.util.Assert;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;




public class Demopage {
	
	
	AndroidDriver driver;



	public Demopage(AndroidDriver driver) {
		
		driver=this.driver;
	//	PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	


	
	    
	

	
	
	//UI element
	
	@AndroidFindBy(id="")
	private WebElement titlebarclock;
	
	@AndroidFindBy(accessibility="Alaram")
	private WebElement AlramElement;
	
	@AndroidFindBy(accessibility="clock")
	private WebElement clockElement;
	
	@AndroidFindBy(accessibility="timer")
	private WebElement timelement;
	
	@AndroidFindBy(accessibility="Stopwatch")
	private WebElement Stopwatch;
	
	
	
	public void clickonAlaram() {
		AlramElement.click();
	}
	
         
	public void clockElement() {
		clockElement.click();
	}
	
	public void varifyStopwatch() {
		boolean StopW = Stopwatch.isDisplayed();
		
	//	Assert.assertTrue(StopW, Stopwatch +"element is visible ");

	}
	
	
	
}
