package tests;

import java.net.MalformedURLException;

import javax.print.DocFlavor.URL;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;

public class BaseTest {
	
	// server On 
	
	
	public static AppiumDriverLocalService service;
	public static AndroidDriver driver;
	@BeforeSuite
	public void StartappiumServer() {
		//to start the Appium server
		AppiumDriverLocalService service = new AppiumServiceBuilder()
                .withIPAddress("127.0.0.1")
                .usingPort(4723)
                .withArgument(GeneralServerFlag.LOG_TIMESTAMP)
                .build();

        // Start the server
        service.start();

        System.out.println("Appium Server Started");

        // Stop the server
    //   service.stop();
		
	}
	
	@BeforeMethod
	public  void sessioncreation() throws MalformedURLException {
		// step1
		if(service!=null) {
				UiAutomator2Options option =new UiAutomator2Options();
				
				//step 2 add the capabilities 
				  option.setCapability("platformName", "Android"); 
				  option.setCapability("automationName","UiAutomator2"); 
				  option.setCapability("udid", "emulator-5554");
				//If the app is installed 
				  option.setCapability("apaPackage", "com.google.android.deskclock");
				  option.setCapability("appActivity", "com.android.deskclock.DeskClock");
				  
				//  option.setCapability("apaPackage", "com.google.android.googlequicksearchbox");
				 // option.setCapability("appActivity", "com.google.android.googlequicksearchbox.OneSearchActivity");
				  
				  
				  
				  
				//If we have .apk with us 
				  //String path 
			//	=System.getProperty("user.dir")+"\\src\\main\\resources\\WikipediaSample.apk"; 
				  //option.setCapability("app",path); 
				  //option.setCapability("noReset",true); 
				  //option.setCapability("autoGrantPermissions", true);
				  
				  //step3
				  
				  URL url=new URL("http://127.0.0.1:4723");
				  
				  //Step4
				 
				   driver =new AndroidDriver(option);
				  
				  //step5
				 String  SessionID = driver.getSessionId().toString();
				 
				 System.out.println("sesion created succesfully and sesionId is:"+SessionID);
		}	 
	}
	
	@Test
	
	public void testserviceCreation() {
		System.out.println("thest the samplecode ");
	}
	@AfterMethod
	public void teardown() {
		if(driver!=null) {
			
			driver.close();
		}
		
	}
	
	@AfterSuite
	public void Stopservice() {
		if (service!=null) {
			
			service.close();
		}
		
	}
	
	
	

}
