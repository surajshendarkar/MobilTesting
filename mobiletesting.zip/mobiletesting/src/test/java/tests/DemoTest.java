package tests;

import org.testng.annotations.Test;

import Pages.Demopage;

public class DemoTest extends BaseTest {

	@Test
	public  void firsttest() {
	
	Demopage page =new Demopage(driver);
	
//	page.clickonAlaram();
	//page .clockElement
	
//	page.varifyStopwatch();
	}
	
	@Test
	public  void secondtest() {
	
	Demopage page =new Demopage(driver);
	
//	page.clickonAlaram();
	//page .clockElement
	
//	page.varifyStopwatch();
	}
	
	
}
