package tests;



import java.net.MalformedURLException;

import javax.print.DocFlavor.URL;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;

public class baseTest2 {

	//copilet code 
	
	public static AppiumDriverLocalService service;
	@BeforeSuite
	public void StartappiumServer() {
	    service = new AppiumServiceBuilder()
	            .withIPAddress("127.0.0.1")
	            .usingPort(4723)
	            .withArgument(GeneralServerFlag.LOG_TIMESTAMP)
	            .build();
	    service.start();
	    System.out.println("Appium Server Started");
	}

	@BeforeMethod
	public void sessioncreation() throws MalformedURLException {
	    if(service != null) {
	        UiAutomator2Options option = new UiAutomator2Options();
	        option.setCapability("platformName", "Android");
	        option.setCapability("automationName", "UiAutomator2");
	        option.setCapability("udid", "emulator-5554");
	        option.setCapability("appPackage", "com.google.android.deskclock");
	        option.setCapability("appActivity", "com.android.deskclock.DeskClock");

	        URL url = new URL("http://127.0.0.1:4723");
	        AndroidDriver driver = new AndroidDriver(option);

	        String sessionID = driver.getSessionId().toString();
	        System.out.println("Session created successfully. SessionId: " + sessionID);
	    }
	}
	
	@AfterSuite
	public void Stopservice() {
	    if(service != null) {
	        service.stop();
	        System.out.println("Appium Server Stopped");
	    }
	}


	
}
